from django.db import models

# Create your models here.
class Poll(models.Model):
    Position=models.CharField(max_length=200)
    candidate_one=models.CharField(max_length=200)
    candidate_two=models.CharField(max_length=200)
    candidate_one_count=models.IntegerField(default=0)
    candidate_two_count=models.IntegerField(default=0)
def __str__(self):
    return self.Position