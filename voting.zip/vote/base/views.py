from django.shortcuts import render,redirect,HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from .models import Poll
from django.contrib.auth.decorators import login_required
from django.contrib import messages



# Create your views here.
#def home(request):
 #   return render(request,'home.html')
def register(request):
     if request.method=='POST':
        Username=request.POST['username']
        email=request.POST['email']
        pass1=request.POST['pass1']
        pass2=request.POST['pass2']

        if pass1!=pass2:
            return HttpResponse("Your password and confrom password are not Same!!")
        else:
            my_user=User.objects.create_user(Username,email,pass1)
            my_user.save()
            return redirect('login')
     return render (request,'register.html')


def login_user(request):
    if request.method=='POST':
        username=request.POST['username']
        pass1=request.POST['pass']
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            return redirect('main')
        else:
            messages.info(request,"Username or Password Incorrect")
            
    return render(request,'login.html')

def logout_user(request):
        logout(request)
        return redirect('login')

@login_required(login_url='login')
def main(request):
     polls=Poll.objects.all()
     context={'polls':polls}
     return render(request,'main.html',context)


@login_required(login_url='login')
def vote(request,poll_id):
    poll=Poll.objects.get(pk=poll_id)
    if request.method=="POST":
        print(request.POST['poll'])
        selected_option=request.POST['poll']
        if selected_option=='candidate_one':
            poll.candidate_one_count+=1
        elif selected_option=='candidate_two':
            poll.candidate_two_count+=1
        else:
            return HttpResponse(400,'ERROR')
        poll.save()
        return redirect('main')
    context={'poll':poll}
    return render(request,'vote.html',context)

@login_required(login_url='login')
def result(request,poll_id):
    poll=Poll.objects.get(pk=poll_id)
    context={'poll':poll}
    return render(request,'result.html',context)


