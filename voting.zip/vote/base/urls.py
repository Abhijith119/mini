from django.urls import path
from .import views
urlpatterns = [
  #  path('home',views.home,name='home'),
    path('register/',views.register,name='register'),
    path('login/',views.login_user,name='login'),
    path('logout/',views.logout_user,name='logout'),
    path('main/',views.main,name='main'),
    path('vote/<poll_id>/',views.vote, name='vote'),
    path('result/<poll_id>/',views.result,name='result'),
 

]
